class Mines:
  def __init__(self, mines):
    self.mines = []
  
  